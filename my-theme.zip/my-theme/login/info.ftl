<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login to Marketplace Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="${url.resourcesPath}/css/login.css">
</head>

<body data-page-id="login-info">
    <div class="custom-login-error-page">
        <div class="login-error-box">
            <header class="login-error-header">
                <h1>Welcome to Marketplace Portal Sign in</h1>
            </header>
            <#-- Display message if present -->
                <#if message?has_content>
                    <p class="verify-msg-login instruction">
                        ${message.summary}
                    </p>
                    <#-- If message indicates profile update, show redirect notice + link -->
                        <#if message.summary=="Your account has been updated.">
                            <div class="centered-link">
                                <p>You will be redirected to the portal shortly.<br>
                                    If the redirection does not happen automatically, please click the button below:</p>
                                <a  href="https://test.developer.api-marketplace.alrajhibank.com.sa/sandbox/">
                                    Visit Portal
                                </a>
                            </div>
                            <meta http-equiv="refresh" content="3;url=https://test.developer.api-marketplace.alrajhibank.com.sa/sandbox/">
                        </#if>
                        <#-- Fallback redirect links (only shown for other messages) -->
                            <#if skipLink??>
                                <#-- No fallback -->
                                    <#else>
                                        <#if pageRedirectUri?has_content>
                                            <p><a href="${pageRedirectUri}">
                                                    ${kcSanitizeF(msg("backToApplication"))?no_esc}
                                                </a></p>
                                            <#elseif actionUri?has_content>
                                                <p><a href="${actionUri}">
                                                        ${kcSanitize(msg("proceedWithAction"))?no_esc}
                                                    </a></p>
                                                <#elseif (client.baseUrl)?has_content>
                                                    <p><a href="${client.baseUrl}">
                                                            ${kcSanitize(msg("backToApplication"))?no_esc}
                                                        </a></p>
                                        </#if>
                            </#if>
                </#if>
        </div>
    </div>
</body>

</html>