<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login to marketplace portal
  </title>
  <link rel="stylesheet" href="${url.resourcesPath}/css/login.css">
</head>
<#-- <#import "template.ftl" as layout>
  <@layout.registrationLayout displayInfo=true displayMessage=!messagesPerField.existsError('username'); section>
    <#if section="header">
      ${msg("emailForgotTitle")}
      <#elseif section="form">
        <form id="kc-reset-password-form" class="${properties.kcFormClass!}" action="${url.loginAction}" method="post">
          <div class="${properties.kcFormGroupClass!}">
            <div class="${properties.kcLabelWrapperClass!}">
              <label for="username" class="${properties.kcLabelClass!}">
                <#if !realm.loginWithEmailAllowed>
                  ${msg("username")}
                  <#elseif !realm.registrationEmailAsUsername>
                    ${msg("usernameOrEmail")}
                    <#else>
                      ${msg("email")}
                </#if>
              </label>
            </div>
            <div class="${properties.kcInputWrapperClass!}">
              <input type="text" id="username" name="username" class="${properties.kcInputClass!}" autofocus value="${(auth.attemptedUsername!'')}" aria-invalid="<#if messagesPerField.existsError('username')>true</#if>" dir="ltr" />
              <#if messagesPerField.existsError('username')>
                <span id="input-error-username" class="${properties.kcInputErrorMessageClass!}" aria-live="polite">
                  ${kcSanitize(messagesPerField.get('username'))?no_esc}
                </span>
              </#if>
            </div>
          </div>
          <div class="${properties.kcFormGroupClass!} ${properties.kcFormSettingClass!}">
            <div id="kc-form-options" class="${properties.kcFormOptionsClass!}">
              <div class="${properties.kcFormOptionsWrapperClass!}">
                <span><a href="${url.loginUrl}">
                    ${kcSanitize(msg("backToLogin"))?no_esc}
                  </a></span>
              </div>
            </div>
            <div id="kc-form-buttons" class="${properties.kcFormButtonsClass!}">
              <input class="${properties.kcButtonClass!} ${properties.kcButtonPrimaryClass!} ${properties.kcButtonBlockClass!} ${properties.kcButtonLargeClass!}" type="submit" value="${msg("doSubmit")}" />
            </div>
          </div>
        </form>
        <#elseif section="info">
          <#if realm.duplicateEmailsAllowed>
            ${msg("emailInstructionUsername")}
            <#else>
              ${msg("emailInstruction")}
          </#if>
    </#if>
  </@layout.registrationLayout> -->

  <body id="keycloak-bg" data-page-id="login-login">
    <div class="custom-login-page">
      <!-- Left image section -->
      <div class="custom-login-left">
        <img src="${url.resourcesPath}/img/login-illustration.png" alt="Welcome" />
      </div>
      <!-- Right login section -->
      <div class="custom-login-right">
        <div class="login-box">
          <header class="login-header">
            <h1>Reset your Marketplace Portal password</h1>
          </header>
          <#-- ERROR MESSAGE BLOCK -->
            <#if message?has_content>
              <div class="alert alert-text ${message.type}">
                <span>
                  ${message.summary}
                </span>
              </div>
            </#if>
            <form id="kc-reset-password-form" class="${properties.kcFormClass!}" action="${url.loginAction}" method="post">
              <div class="form-group">
                <label for="username">
                  ${msg("usernameOrEmail")}
                </label>
                <input id="username"
                  name="username"
                  type="text"
                  autocomplete="username"
                  value="${(loginHint)!''}"
                  required />
              </div>
              <input type="hidden" id="id-hidden-input" name="credentialId" />
              <div class="form-actions">
                <button id="kc-form-buttons" name="login" type="submit">
                  ${msg("doSubmit")}
                </button>
              </div>
              <span><a href="${url.loginUrl}">
                  ${kcSanitize(msg("backToLogin"))?no_esc}
                </a></span>
            </form>
        </div>
      </div>
    </div>
  </body>

</html>